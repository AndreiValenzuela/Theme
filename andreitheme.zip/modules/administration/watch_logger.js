$(document).ready(function() {
$('input[src="modules/administration/images/remove.gif"]').replaceWith('<button name="remove_log" class="remove_log" onclick="this.form.submit();"></button>');
});
